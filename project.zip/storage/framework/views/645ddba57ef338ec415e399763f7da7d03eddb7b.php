<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/components/menu-title.blade.php ENDPATH**/ ?>