<div class="row">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($link['link'])): ?>
                        <li class="breadcrumb-item"><a href="<?php echo e($link['link']); ?>"><?php echo e($link['name']); ?></a></li>

                    <?php else: ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($link['name']); ?></li>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ol>
        </nav>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/my_class/laravel/front-end/laravel7/resources/views/layouts/breadcrumb.blade.php ENDPATH**/ ?>