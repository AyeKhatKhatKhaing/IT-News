<li class="menu-spacer"></li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/my_class/laravel/front-end/laravel7/resources/views/components/menu-spacer.blade.php ENDPATH**/ ?>