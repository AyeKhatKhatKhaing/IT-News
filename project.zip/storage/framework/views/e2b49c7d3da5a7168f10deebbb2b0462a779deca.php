<?php $__env->startSection("title"); ?> Sample Page <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item active" aria-current="page">Article List</li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="feather-list">Article List</h4>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <a class="btn btn-outline-primary btn-lg feather-plus-circle mr-3" href="<?php echo e(route('article.create')); ?>">Add Article</a>
                            <?php if(isset(request()->search)): ?>
                                <a class="btn btn-outline-dark btn-lg feather-list mr-3" href="<?php echo e(route('article.index')); ?>">Article List</a>
                            <?php endif; ?>
                        </div>
                        <form action="<?php echo e(route('article.index')); ?>" method="get">
                            <div class="form-inline">
                                <input type="text" class="form-control form-control-lg" name="search" placeholder="Search Article">
                                <button class="btn btn-primary btn-lg feather-search ml-2" type="submit"></button>
                            </div>
                        </form>
                    </div>
                    <hr>
                    <?php if(session('message')): ?>
                        <p class="alert alert-success"><?php echo e(session('message')); ?></p>
                    <?php endif; ?>
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <td>#</td>
                            <td>Article</td>
                            <td>Owner</td>
                            <td>Category</td>
                            <td>Controls</td>
                            <td>Created At</td>
                        </tr>
                        </thead>
                        <tbody>
                      <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($article->id); ?></td>
                                <td>
                                    <span class="font-weight-bolder"><?php echo e(\Illuminate\Support\Str::words($article->title,5)); ?></span><br>
                                    <small class="text-muted"><?php echo e(\Illuminate\Support\Str::words($article->description,8)); ?></small>
                                </td>
                                <td><?php echo e($article->user->name); ?></td>
                                <td><?php echo e($article->category->title); ?></td>
                                <td class="text-nowrap">
                                    <a href="<?php echo e(route('article.show',$article->id)); ?>" class="btn btn-outline-success">
                                        Show
                                    </a>
                                    <a href="<?php echo e(route('article.edit',$article->id)); ?>" class="btn btn-outline-primary">
                                        Edit
                                    </a>
                                    <form action="<?php echo e(route('article.destroy',[$article->id,'page'=>request()->page])); ?>" method="post" class="d-inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete <?php echo e($article->title); ?>')">Delete</button>
                                    </form>
                                </td>
                                <td>
                                    <span class="feather-calendar"><?php echo e($article->created_at->format("d m Y")); ?></span>
                                    <br>
                                    <span class="feather-clock "><?php echo e($article->created_at->format("h i A")); ?></span>
                                </td>
                            </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="6" class="text-center">There is no Article</td>
                          </tr>

                      <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-between">
                        <?php echo e($articles->appends(request()->all())->links()); ?>

                        <p class="h4 font-weight-bolder">Total : <?php echo e($articles->total()); ?></p>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/article/index.blade.php ENDPATH**/ ?>