<?php $__env->startSection("title"); ?> Article Detail <?php $__env->stopSection(); ?>
<?php $__env->startSection('head'); ?>
    <style>
        .description{
            white-space: pre-line;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <?php if (isset($component)) { $__componentOriginal30091868428b09767320233ef70f89faadea10d9 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BreadCrumb::class, []); ?>
<?php $component->withName('bread-crumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        <li class="breadcrumb-item"><a href="<?php echo e(route('article.index')); ?>">Article List</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($article->title); ?></li>
     <?php if (isset($__componentOriginal30091868428b09767320233ef70f89faadea10d9)): ?>
<?php $component = $__componentOriginal30091868428b09767320233ef70f89faadea10d9; ?>
<?php unset($__componentOriginal30091868428b09767320233ef70f89faadea10d9); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

    <div class="row">
        <div class="col-12 col-md-6">
            <div class="card">
                <div class="card-body">
                    <h4><?php echo e($article->title); ?></h4>
                    <div class="text-primary font-weight-bolder">
                        <span class="mr-2 feather-user"><?php echo e($article->user->name); ?></span>
                        <span class="mr-2 feather-layers"><?php echo e($article->category->title); ?></span>
                        <span class="mr-2 feather-calendar"><?php echo e($article->created_at->format("d-m-Y")); ?></span>
                        <span class="mr-2 feather-clock "><?php echo e($article->created_at->format("h:i A")); ?></span>
                    </div>
                    <hr>
                    <p class="description"><?php echo e($article->description); ?></p>
                    <hr>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <a href="<?php echo e(route('article.edit',$article->id)); ?>" class="btn btn-outline-primary">
                                Edit
                            </a>
                            <a href="<?php echo e(route('article.index')); ?>" class="btn btn-outline-dark">
                                Article List
                            </a>
                            <form action="<?php echo e(route('article.destroy',$article->id)); ?>" method="post" class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete this article?')">Delete</button>
                            </form>
                        </div>
                        <p class="mb-0"><?php echo e($article->created_at->diffForHumans()); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/article/show.blade.php ENDPATH**/ ?>