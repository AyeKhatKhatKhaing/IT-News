<li class="menu-spacer"></li>
<?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>