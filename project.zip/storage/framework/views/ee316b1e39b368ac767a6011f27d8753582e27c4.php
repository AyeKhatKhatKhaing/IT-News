<h1>Welcome</h1>
<a href="<?php echo e(route('login')); ?>">login</a>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/my_class/laravel/front-end/laravel7/resources/views/welcome.blade.php ENDPATH**/ ?>