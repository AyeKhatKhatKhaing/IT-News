<?php $__env->startSection("content"); ?>
    <h1>I am about</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("Blog.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/Blog/about.blade.php ENDPATH**/ ?>