<li class="menu-title">
    <span>{{ $title }}</span>
</li>
