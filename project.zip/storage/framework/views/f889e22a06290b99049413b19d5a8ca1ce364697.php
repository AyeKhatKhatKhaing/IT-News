<table class="table table-hover">
    <thead>
    <tr>
        <td>#</td>
        <td>Title</td>
        <td>Owner</td>
        <td>Controls</td>
        <td>Created At</td>
    </tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = \App\Category::with("user")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($c->id); ?></td>
            <td><?php echo e($c->title); ?></td>
            <td><?php echo e($c->user->name); ?></td>
            <td>
                <a href="<?php echo e(route('category.edit',$c->id)); ?>" class="btn btn-outline-primary">
                    Edit
                </a>
                <form action="<?php echo e(route('category.destroy',$c->id)); ?>" method="post" class="d-inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-outline-danger" onclick="return confirm('Are you sure to delete <?php echo e($c->title); ?>')">Delete</button>
                </form>
            </td>
            <td>
                <span class="feather-calendar"><?php echo e($c->created_at->format("d m Y")); ?></span>
                <br>
                <span class="feather-clock "><?php echo e($c->created_at->format("h i A")); ?></span>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="5">There is no category</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\Laravel\it-news\project\resources\views/Category/list.blade.php ENDPATH**/ ?>