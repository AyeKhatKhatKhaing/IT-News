<?php

namespace App\Http\Controllers;

use App\Article;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function index(){
        $articles=Article::when(isset(request()->search),function ($q){
            $search=request()->search;
            return $q->where("title","like","%$search%")->orwhere("description","like","%$search%");
        })
            ->with('user','category')->latest('id')->paginate(10);
        return view('welcome',compact('articles'));
    }

    public function detail($id){
        $article=Article::find($id);
        return view('Blog.detail',compact('article'));
    }

    public function byCategory($id){
        $articles=Article::when(isset(request()->search),function ($q){
            $search=request()->search;
            return $q->where("title","like","%$search%")->orwhere("description","like","%$search%");
        })
            ->where('category_id',$id)->with('user','category')->latest('id')->paginate(10);
        return view('welcome',compact('articles'));
    }

    public function byUser($id){
        $articles=Article::where('user_id',$id)->when(isset(request()->search),function ($q){
            $search=request()->search;
            return $q->where("title","like","%$search%")->orwhere("description","like","%$search%");
        })
            ->with('user','category')->latest('id')->paginate(10);
        return view('welcome',compact('articles'));
    }

    public function byDate($date){
        $articles=Article::where('created_at',$date)->when(isset(request()->search),function ($q){
            $search=request()->search;
            return $q->where("title","like","%$search%")->orwhere("description","like","%$search%");
        })
            ->with('user','category')->latest('id')->paginate(10);
        return view('welcome',compact('articles'));
    }
}
