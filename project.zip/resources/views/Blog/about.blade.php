@extends("Blog.master")
@section("content")
    <h1>I am about</h1>
@endsection
