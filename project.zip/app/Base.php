<?php
namespace App;

class Base
{
    public static $name="IT News";
    public static $logo='images/logos/logo.PNG';
    public static $description="IT သတင်းတွေကို တင်မယ် ဖတ်မယ်";

}
